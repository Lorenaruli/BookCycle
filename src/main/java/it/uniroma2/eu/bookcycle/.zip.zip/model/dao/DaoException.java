package it.uniroma2.eu.bookcycle.model.dao;

public class DaoException extends RuntimeException {
    public DaoException(String message) {
        super(message);
    }
}
