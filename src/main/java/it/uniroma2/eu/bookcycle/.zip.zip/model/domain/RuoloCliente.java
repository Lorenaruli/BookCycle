package it.uniroma2.eu.bookcycle.model.domain;

public enum RuoloCliente {
    UTENTE,
    LIBRAIO
}
