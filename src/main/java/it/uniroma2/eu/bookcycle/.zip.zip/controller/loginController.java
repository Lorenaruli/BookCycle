package it.uniroma2.eu.bookcycle.controller;

public class loginController {
    private ClienteDAO clienteDAO;

}
