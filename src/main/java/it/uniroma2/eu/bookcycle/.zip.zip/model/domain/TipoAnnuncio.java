package it.uniroma2.eu.bookcycle.model.domain;

public enum TipoAnnuncio {
    ANNUNCIOVENDITA,
    ANNUNCIONOLEGGIO
}
